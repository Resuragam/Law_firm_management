import{g as o,h as r,o as n,r as t}from"./app.be8463ae.js";const c={};function s(_,a){const e=t("router-view");return n(),r(e)}const i=o(c,[["render",s]]);export{i as default};
