import{g as e}from"./app.8b382ddc.js";const n={};function r(c,t){return" login "}const _=e(n,[["render",r]]);export{_ as default};
