import{g as o,h as r,o as n,r as t}from"./app.e7b95ba4.js";const c={};function s(_,a){const e=t("router-view");return n(),r(e)}const i=o(c,[["render",s]]);export{i as default};
